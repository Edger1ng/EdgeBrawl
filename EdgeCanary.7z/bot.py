import asyncio
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.types import CallbackQuery
from aiogram.filters.command import Command
from DataBase.DBManager import DB

TOKEN="7024035753:AAEBoXGer2tVs5bwrjafV7NUkw978Gnh-H0"
bot = Bot(token=TOKEN)
admin_ids = [2128436782]
db = DB()
dp = Dispatcher()


@dp.message(Command('start'))
async def start_handler(message: types.Message):

    if int(message.from_user.id) in admin_ids:
        await message.reply("Привет, мой пупсик.Ты должен прислать мне сообщения типа:\n/update arg1 arg2 arg3\n/info arg1")
    else:
        await message.reply("Ты кто!")

@dp.message(Command('update'))
async def update_handler(message: types.Message):
    if int(message.from_user.id) in admin_ids:
        arg1 = str(message.text.split(' ')[1])
        arg2 = str(message.text.split(' ')[2])
        arg3 = message.text.split(' ')[3]
        arg4 = message.text.split(' ')[4]
        
        if arg4 == "int":
            db.update_player_account(arg1, arg2, int(arg3))
        if arg4 == "bool":
            if arg3 == "False":
                db.update_player_account(arg1, arg2, False)
            if arg3 == "True":
                db.update_player_account(arg1, arg2, True)
        if arg4 == "str":
            db.update_player_account(arg1, arg2, str(arg3))
        await message.reply(f"Upd Player Account:\n{arg1}\n{arg2}\n{arg3}")
    else:
        await message.reply("Я тя не знаю, бро")


@dp.message(Command('info'))
async def info_handler(message: types.Message):
    if int(message.from_user.id) in admin_ids:
        arg1 = int(message.text.split(' ')[1])
        player_data = db.load_player_account_by_id(arg1)
        try:
            await message.reply(f"FULL DATA\n\n{player_data}")
        except:
            await message.reply("Too Long:(")
        await message.reply(f"TOKEN:\n{player_data['Token']}\n\nID:\n{player_data['ID']}")
    else:
        await message.reply("Ваши данные успешно отправлены на СВО")


@dp.message(Command('updateall'))
async def all_handler(message: types.Message):
    if int(message.from_user.id) in admin_ids:
        arg1 = str(message.text.split(' ')[1])
        arg2 = message.text.split(' ')[2]
        arg3 = message.text.split(' ')[3]
        if arg3 == "int":
            db.update_all_players(None, arg1, int(arg2))
        if arg3 == "bool":
            if arg2 == "False":
                db.update_all_players(None, arg1, False)
            if arg2 == "True":
                db.update_all_players(None, arg1, True)
        if arg3 == "str":
            db.update_all_players(None, arg1, str(arg2))

@dp.message(Command('resetbp'))
async def reset_handler(message: types.Message):
    if int(message.from_user.id) in admin_ids:
        arg1 = str(message.text.split(' ')[1])
        arg2 = int(message.text.split(' ')[2])
        reserve = db.load_player_account_by_id(arg2)
        db.update_player_account(arg1, 'PassTokens', reserve['ReserveTokens'])
        db.update_player_account(arg1, 'FreePassClaimed', [0])
        db.update_player_account(arg1, 'DonatePassClaimed', [0])
        db.update_player_account(arg1, 'BrawlPassActivated', False)
        await message.reply("Upgraded!")
    else:
        await message.reply("Да уебашь отсюда!")


@dp.message(Command('resetbpall'))
async def reset_handler(message: types.Message):
    if int(message.from_user.id) in admin_ids:
        db.update_all_players(None, 'PassTokens', 0)
        db.update_all_players(None, 'FreePassClaimed', [0])
        db.update_all_players(None, 'DonatePassClaimed', [0])
        db.update_all_players(None, 'BrawlPassActivated', False)
        await message.reply("Upgraded!")
    else:
        await message.reply("Да уебашь отсюда!")


async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())